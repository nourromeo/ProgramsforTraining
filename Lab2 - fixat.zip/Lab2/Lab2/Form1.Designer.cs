﻿
namespace Lab2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.AntalDragTextBox = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SjuRattTextBox = new System.Windows.Forms.TextBox();
            this.SexRattTextBox = new System.Windows.Forms.TextBox();
            this.FemRattTextBox = new System.Windows.Forms.TextBox();
            this.AntalDragLabel = new System.Windows.Forms.Label();
            this.DinLottoradLabel = new System.Windows.Forms.Label();
            this.SexRattLabel = new System.Windows.Forms.Label();
            this.FemRattLabel = new System.Windows.Forms.Label();
            this.SjuRattLabel = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(192, 27);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(100, 26);
            this.textBox1.TabIndex = 0;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(298, 27);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(100, 26);
            this.textBox2.TabIndex = 1;
            // 
            // AntalDragTextBox
            // 
            this.AntalDragTextBox.Location = new System.Drawing.Point(460, 88);
            this.AntalDragTextBox.Name = "AntalDragTextBox";
            this.AntalDragTextBox.Size = new System.Drawing.Size(124, 26);
            this.AntalDragTextBox.TabIndex = 2;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(510, 27);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(100, 26);
            this.textBox4.TabIndex = 3;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(616, 27);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(100, 26);
            this.textBox5.TabIndex = 4;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(722, 27);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(100, 26);
            this.textBox6.TabIndex = 5;
            // 
            // textBox7
            // 
            this.textBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBox7.Location = new System.Drawing.Point(829, 27);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(100, 26);
            this.textBox7.TabIndex = 6;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(404, 27);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(100, 26);
            this.textBox3.TabIndex = 7;
            // 
            // SjuRattTextBox
            // 
            this.SjuRattTextBox.Location = new System.Drawing.Point(722, 194);
            this.SjuRattTextBox.Name = "SjuRattTextBox";
            this.SjuRattTextBox.Size = new System.Drawing.Size(100, 26);
            this.SjuRattTextBox.TabIndex = 8;
            // 
            // SexRattTextBox
            // 
            this.SexRattTextBox.Location = new System.Drawing.Point(497, 194);
            this.SexRattTextBox.Name = "SexRattTextBox";
            this.SexRattTextBox.Size = new System.Drawing.Size(100, 26);
            this.SexRattTextBox.TabIndex = 9;
            // 
            // FemRattTextBox
            // 
            this.FemRattTextBox.Location = new System.Drawing.Point(282, 194);
            this.FemRattTextBox.Name = "FemRattTextBox";
            this.FemRattTextBox.Size = new System.Drawing.Size(100, 26);
            this.FemRattTextBox.TabIndex = 10;
            // 
            // AntalDragLabel
            // 
            this.AntalDragLabel.AutoSize = true;
            this.AntalDragLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AntalDragLabel.Location = new System.Drawing.Point(248, 87);
            this.AntalDragLabel.Name = "AntalDragLabel";
            this.AntalDragLabel.Size = new System.Drawing.Size(184, 25);
            this.AntalDragLabel.TabIndex = 11;
            this.AntalDragLabel.Text = "Antal dragningar: ";
            // 
            // DinLottoradLabel
            // 
            this.DinLottoradLabel.AutoSize = true;
            this.DinLottoradLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DinLottoradLabel.Location = new System.Drawing.Point(21, 28);
            this.DinLottoradLabel.Name = "DinLottoradLabel";
            this.DinLottoradLabel.Size = new System.Drawing.Size(136, 25);
            this.DinLottoradLabel.TabIndex = 12;
            this.DinLottoradLabel.Text = "Din Lottorad:";
            // 
            // SexRattLabel
            // 
            this.SexRattLabel.AutoSize = true;
            this.SexRattLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SexRattLabel.Location = new System.Drawing.Point(399, 193);
            this.SexRattLabel.Name = "SexRattLabel";
            this.SexRattLabel.Size = new System.Drawing.Size(81, 25);
            this.SexRattLabel.TabIndex = 13;
            this.SexRattLabel.Text = "6 Rätt: ";
            // 
            // FemRattLabel
            // 
            this.FemRattLabel.AutoSize = true;
            this.FemRattLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FemRattLabel.Location = new System.Drawing.Point(187, 193);
            this.FemRattLabel.Name = "FemRattLabel";
            this.FemRattLabel.Size = new System.Drawing.Size(81, 25);
            this.FemRattLabel.TabIndex = 14;
            this.FemRattLabel.Text = "5 Rätt: ";
            // 
            // SjuRattLabel
            // 
            this.SjuRattLabel.AutoSize = true;
            this.SjuRattLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SjuRattLabel.Location = new System.Drawing.Point(627, 193);
            this.SjuRattLabel.Name = "SjuRattLabel";
            this.SjuRattLabel.Size = new System.Drawing.Size(81, 25);
            this.SjuRattLabel.TabIndex = 15;
            this.SjuRattLabel.Text = "7 Rätt: ";
            // 
            // button1
            // 
            this.button1.AutoEllipsis = true;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.button1.FlatAppearance.BorderSize = 5;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(604, 80);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(188, 47);
            this.button1.TabIndex = 16;
            this.button1.Text = "Starta Lotto";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.StartaLotto_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(951, 239);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.SjuRattLabel);
            this.Controls.Add(this.FemRattLabel);
            this.Controls.Add(this.SexRattLabel);
            this.Controls.Add(this.DinLottoradLabel);
            this.Controls.Add(this.AntalDragLabel);
            this.Controls.Add(this.FemRattTextBox);
            this.Controls.Add(this.SexRattTextBox);
            this.Controls.Add(this.SjuRattTextBox);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox7);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox4);
            this.Controls.Add(this.AntalDragTextBox);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.MaximumSize = new System.Drawing.Size(973, 295);
            this.MinimumSize = new System.Drawing.Size(973, 295);
            this.Name = "Form1";
            this.Text = "Lotto program";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox AntalDragTextBox;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox SjuRattTextBox;
        private System.Windows.Forms.TextBox SexRattTextBox;
        private System.Windows.Forms.TextBox FemRattTextBox;
        private System.Windows.Forms.Label AntalDragLabel;
        private System.Windows.Forms.Label DinLottoradLabel;
        private System.Windows.Forms.Label SexRattLabel;
        private System.Windows.Forms.Label FemRattLabel;
        private System.Windows.Forms.Label SjuRattLabel;
        private System.Windows.Forms.Button button1;
    }
}

