﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.IO;


namespace Lab2
{
    public partial class Form1 : Form
    {
        uint antalDragning;


        public Form1()
        {
            InitializeComponent();
        }

        // här byggar jag starta lotto button..
        private void button1_Click(object sender, EventArgs e)
        {

            if (TextBoxInput() == false)
            {
                return;
            }
            int antalDragning = HamtaAntalDragningar();

            for (int i = 0; i < antalDragning; i++)
            {
                HittaRattNummer(SlumpTal());
                nummerList.Clear();
            }

        }

        
        private int[] textBox = new int[7];
        private List<int> nummerList = new List<int>();
        private int FemRatt = 0, SexRatt = 0, SjuRatt = 0;


        private bool Nummer(int i, int j)
        {
            if (textBox.Contains(i) && (Array.IndexOf(textBox, i) != j))
            {
                return true;
            }

            return false;
        }

        // för att läsa textbox och sedan se till att siffror är unika.
        private bool TextBoxInput()
        {
            try
            {
                textBox[0] = int.Parse(textBox1.Text);
                textBox[1] = int.Parse(textBox2.Text);
                textBox[2] = int.Parse(textBox3.Text);
                textBox[3] = int.Parse(textBox4.Text);
                textBox[4] = int.Parse(textBox5.Text);
                textBox[5] = int.Parse(textBox6.Text);
                textBox[6] = int.Parse(textBox7.Text);

                for (int i = 0; i <= 6; i++)
                {
                        if (textBox[i] > 35 || textBox[i] == 0 || Nummer(textBox[i], i))
                        throw new Exception();
                }

            }
            catch (Exception ee)
            {
                MessageBox.Show("Fel! Vänligen välj unika nr mellan 1 och 35.", "Viktigt Medelande");
                return false;
            }
            return true;
        }

        // hämta antal dragningar som användaren skriver.
        private int HamtaAntalDragningar()
        {
            try
            {
                if ( antalDragning < 0 ){
                    MessageBox.Show("Fel! Antal dragningar måste vara en positiv tal");
                    return 0;
                } else
                {
                    antalDragning = uint.Parse(AntalDragTextBox.Text);
                }

                return (int)antalDragning;
            }
            catch
            {
                _ = MessageBox.Show("Antal dragningar kan inte vara töm!!");
                return 0;
            }

        }

        // skapar en slump tal mellan 1 och 35
        private int GenereraRand(int maxSlumpTal)
        {
            int rand;
            Random random = new Random();
            rand = (int)nummerList[random.Next(1, maxSlumpTal)];

            return rand;


        }

        /* använder slumptalet och kollar om slumptal == den inmatade tal, 
         * och sedan addera ratt med 1, annars addera wrong med 1
        */

        private uint SlumpTal()
        {
            int maxSlumpTal = 35;
            uint ratt = 0;
            uint wrong = 0;

            for (int i = 1; i <= maxSlumpTal; i++)
            {
                nummerList.Add(i);
            }

            for (int i = 0; i <= 6; i++)
            {
                if (textBox.Contains((int)GenereraRand(maxSlumpTal--)))
                {
                    ratt++;
                }
                else
                {
                    wrong++;
                    if (wrong > 3)
                        return wrong;
                }
            }

            return ratt;
        }

        /*
         * här fyller man den rätt textbox.
         */
        private void HittaRattNummer(uint ratt)
        {
            switch (ratt)
            {
                case 5:
                    FemRatt++;
                    break;
                case 6:
                    SexRatt++;
                    break;
                case 7:
                    SjuRatt++;
                    break;
                default:
                    break;
            }

            FemRattTextBox.Text = FemRatt.ToString();
            SexRattTextBox.Text = SexRatt.ToString();
            SjuRattTextBox.Text = SjuRatt.ToString();

        }

    }
}
